from decimal import Decimal

from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models

MONTO_MINIMO = Decimal('1')
MONTO_MAXIMO = Decimal('999999999')


def validadores_monto():
    return [MinValueValidator(MONTO_MINIMO), MaxValueValidator(MONTO_MAXIMO)]


class Categoria(models.Model):
    """Agrupa los movimientos del usuario (ej: Alimentacion, Transporte, Sueldo)."""

    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='categorias'
    )
    nombre = models.CharField(max_length=60)

    class Meta:
        ordering = ['nombre']
        constraints = [
            models.UniqueConstraint(
                fields=['usuario', 'nombre'], name='categoria_unica_por_usuario'
            )
        ]

    def __str__(self):
        return self.nombre


class Movimiento(models.Model):
    """Ingreso o gasto registrado por el usuario."""

    INGRESO = 'ingreso'
    GASTO = 'gasto'
    TIPOS = [(INGRESO, 'Ingreso'), (GASTO, 'Gasto')]

    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='movimientos'
    )
    categoria = models.ForeignKey(
        Categoria, on_delete=models.PROTECT, related_name='movimientos'
    )
    tipo = models.CharField(max_length=10, choices=TIPOS)
    monto = models.DecimalField(max_digits=12, decimal_places=0, validators=validadores_monto())
    fecha = models.DateField()
    descripcion = models.CharField(max_length=200, blank=True)
    creado = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-fecha', '-id']
        indexes = [models.Index(fields=['usuario', 'fecha'])]

    def __str__(self):
        return f'{self.get_tipo_display()} ${self.monto} ({self.fecha})'


class Presupuesto(models.Model):
    """Monto maximo de gasto para una categoria en un mes determinado."""

    categoria = models.ForeignKey(
        Categoria, on_delete=models.CASCADE, related_name='presupuestos'
    )
    mes = models.DateField(help_text='Siempre se guarda el dia 1 del mes')
    monto_maximo = models.DecimalField(
        max_digits=12, decimal_places=0, validators=validadores_monto()
    )

    class Meta:
        ordering = ['-mes', 'categoria__nombre']
        constraints = [
            models.UniqueConstraint(
                fields=['categoria', 'mes'],
                name='presupuesto_unico_por_categoria_y_mes',
            )
        ]

    def __str__(self):
        return f'{self.categoria} - {self.mes:%m/%Y}'


class Alerta(models.Model):
    """Aviso generado cuando el gasto alcanza o supera un presupuesto."""

    ADVERTENCIA = 'advertencia'
    EXCEDIDO = 'excedido'
    TIPOS = [(ADVERTENCIA, 'Advertencia (80%)'), (EXCEDIDO, 'Presupuesto excedido')]

    presupuesto = models.ForeignKey(
        Presupuesto, on_delete=models.CASCADE, related_name='alertas'
    )
    tipo = models.CharField(max_length=15, choices=TIPOS)
    porcentaje = models.PositiveIntegerField()
    fecha_hora = models.DateTimeField(auto_now_add=True)
    leida = models.BooleanField(default=False)

    class Meta:
        ordering = ['-fecha_hora', '-id']

    def __str__(self):
        return f'{self.get_tipo_display()} - {self.presupuesto}'
