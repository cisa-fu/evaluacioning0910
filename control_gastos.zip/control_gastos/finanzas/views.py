import csv
from datetime import datetime

from django.contrib import messages
from django.contrib.auth import views as auth_views
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Count
from django.db.models.deletion import ProtectedError
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect
from django.shortcuts import render
from django.urls import reverse_lazy
from django.utils import timezone
from django.views.decorators.http import require_POST
from django.views.generic import CreateView, DeleteView, ListView, UpdateView

from .forms import (
    ANIO_MAXIMO, ANIO_MINIMO, CategoriaForm, FiltroMovimientosForm,
    MovimientoForm, PresupuestoForm, RegistroForm,
)
from .models import Alerta, Categoria, Movimiento, Presupuesto
from .services import (
    crear_categorias_iniciales, evaluar_movimiento, evaluar_presupuesto,
    filtrar_movimientos, resumen_mensual,
)


# --- Autenticacion ----------------------------------------------------------

class InicioSesionView(auth_views.LoginView):
    redirect_authenticated_user = True


class RegistroView(CreateView):
    form_class = RegistroForm
    template_name = 'registration/registro.html'
    success_url = reverse_lazy('login')

    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect('principal')
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        respuesta = super().form_valid(form)
        crear_categorias_iniciales(self.object)
        messages.success(self.request, 'Cuenta creada correctamente. Ya puede iniciar sesion')
        return respuesta


# --- Mixins -----------------------------------------------------------------

class FormularioMixin(LoginRequiredMixin):
    """Pasa el usuario al formulario y los textos comunes a la plantilla."""
    template_name = 'finanzas/form.html'
    titulo = ''
    volver = 'principal'

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto['titulo'] = self.titulo
        contexto['volver'] = self.volver
        return contexto


class EliminarMixin(LoginRequiredMixin):
    template_name = 'finanzas/confirmar_eliminar.html'
    mensaje_ok = 'Registro eliminado correctamente'
    volver = 'principal'

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto['volver'] = self.volver
        return contexto

    def form_valid(self, form):
        respuesta = super().form_valid(form)
        messages.success(self.request, self.mensaje_ok)
        return respuesta


# --- Resumen mensual --------------------------------------------------------

def _mes_solicitado(request):
    """Lee ?mes=AAAA-MM; ante cualquier valor invalido usa el mes actual."""
    hoy = timezone.localdate()
    try:
        mes = datetime.strptime(request.GET.get('mes', ''), '%Y-%m').date()
    except ValueError:
        return hoy.replace(day=1)
    if not ANIO_MINIMO <= mes.year <= ANIO_MAXIMO:
        return hoy.replace(day=1)
    return mes


@login_required
def principal(request):
    mes = _mes_solicitado(request)
    contexto = resumen_mensual(request.user, mes)
    contexto['mes_valor'] = mes.strftime('%Y-%m')
    return render(request, 'finanzas/principal.html', contexto)


# --- Categorias -------------------------------------------------------------

class CategoriaListView(LoginRequiredMixin, ListView):
    template_name = 'finanzas/categoria_list.html'
    context_object_name = 'categorias'

    def get_queryset(self):
        return Categoria.objects.filter(usuario=self.request.user).annotate(
            cantidad=Count('movimientos')
        )


class CategoriaCreateView(FormularioMixin, CreateView):
    form_class = CategoriaForm
    success_url = reverse_lazy('categoria_lista')
    titulo = 'Nueva categoria'
    volver = 'categoria_lista'

    def form_valid(self, form):
        form.instance.usuario = self.request.user
        respuesta = super().form_valid(form)
        messages.success(self.request, 'Categoria creada correctamente')
        return respuesta


class CategoriaUpdateView(FormularioMixin, UpdateView):
    form_class = CategoriaForm
    success_url = reverse_lazy('categoria_lista')
    titulo = 'Modificar categoria'
    volver = 'categoria_lista'

    def get_queryset(self):
        return Categoria.objects.filter(usuario=self.request.user)

    def form_valid(self, form):
        respuesta = super().form_valid(form)
        messages.success(self.request, 'Categoria modificada correctamente')
        return respuesta


class CategoriaDeleteView(EliminarMixin, DeleteView):
    success_url = reverse_lazy('categoria_lista')
    volver = 'categoria_lista'
    mensaje_ok = 'Categoria eliminada correctamente'

    def get_queryset(self):
        return Categoria.objects.filter(usuario=self.request.user)

    def form_valid(self, form):
        try:
            return super().form_valid(form)
        except ProtectedError:
            messages.error(
                self.request,
                'No se puede eliminar una categoria que tiene movimientos registrados',
            )
            return redirect('categoria_lista')


# --- Movimientos ------------------------------------------------------------

def _filtro(request):
    datos = request.GET if request.GET else None
    return FiltroMovimientosForm(datos, user=request.user)


class MovimientoListView(LoginRequiredMixin, ListView):
    template_name = 'finanzas/movimiento_list.html'
    context_object_name = 'movimientos'
    paginate_by = 10

    def get_queryset(self):
        self.filtro = _filtro(self.request)
        return filtrar_movimientos(self.request.user, self.filtro)

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        parametros = self.request.GET.copy()
        parametros.pop('page', None)
        contexto['filtro'] = self.filtro
        contexto['querystring'] = parametros.urlencode()
        return contexto


class MovimientoCreateView(FormularioMixin, CreateView):
    form_class = MovimientoForm
    success_url = reverse_lazy('movimiento_lista')
    titulo = 'Registrar movimiento'
    volver = 'movimiento_lista'

    def form_valid(self, form):
        form.instance.usuario = self.request.user
        respuesta = super().form_valid(form)
        messages.success(self.request, 'Movimiento registrado correctamente')
        _avisar_si_hay_alerta(self.request, evaluar_movimiento(self.object))
        return respuesta


class MovimientoUpdateView(FormularioMixin, UpdateView):
    form_class = MovimientoForm
    success_url = reverse_lazy('movimiento_lista')
    titulo = 'Modificar movimiento'
    volver = 'movimiento_lista'

    def get_queryset(self):
        return Movimiento.objects.filter(usuario=self.request.user)

    def form_valid(self, form):
        respuesta = super().form_valid(form)
        messages.success(self.request, 'Movimiento modificado correctamente')
        _avisar_si_hay_alerta(self.request, evaluar_movimiento(self.object))
        return respuesta


class MovimientoDeleteView(EliminarMixin, DeleteView):
    success_url = reverse_lazy('movimiento_lista')
    volver = 'movimiento_lista'
    mensaje_ok = 'Movimiento eliminado correctamente'

    def get_queryset(self):
        return Movimiento.objects.filter(usuario=self.request.user)


def _avisar_si_hay_alerta(request, alerta):
    if alerta is not None:
        messages.warning(
            request, f'Atencion: {alerta.get_tipo_display()} en {alerta.presupuesto.categoria}'
        )


def _neutralizar_formula(texto):
    """Evita inyeccion de formulas al abrir el CSV en una planilla."""
    texto = str(texto)
    if texto and texto[0] in '=+-@\t\r':
        return "'" + texto
    return texto


@login_required
def movimientos_exportar(request):
    movimientos = filtrar_movimientos(request.user, _filtro(request))
    respuesta = HttpResponse(content_type='text/csv; charset=utf-8')
    respuesta['Content-Disposition'] = 'attachment; filename="movimientos.csv"'
    escritor = csv.writer(respuesta)
    escritor.writerow(['Fecha', 'Tipo', 'Categoria', 'Monto', 'Descripcion'])
    for m in movimientos:
        escritor.writerow([
            m.fecha.isoformat(), m.get_tipo_display(),
            _neutralizar_formula(m.categoria.nombre), m.monto,
            _neutralizar_formula(m.descripcion),
        ])
    return respuesta


# --- Presupuestos -----------------------------------------------------------

class PresupuestoListView(LoginRequiredMixin, ListView):
    template_name = 'finanzas/presupuesto_list.html'
    context_object_name = 'presupuestos'

    def get_queryset(self):
        return Presupuesto.objects.filter(
            categoria__usuario=self.request.user
        ).select_related('categoria')


class PresupuestoCreateView(FormularioMixin, CreateView):
    form_class = PresupuestoForm
    success_url = reverse_lazy('presupuesto_lista')
    titulo = 'Nuevo presupuesto'
    volver = 'presupuesto_lista'

    def form_valid(self, form):
        respuesta = super().form_valid(form)
        messages.success(self.request, 'Presupuesto configurado correctamente')
        _avisar_si_hay_alerta(self.request, evaluar_presupuesto(self.object))
        return respuesta


class PresupuestoUpdateView(FormularioMixin, UpdateView):
    form_class = PresupuestoForm
    success_url = reverse_lazy('presupuesto_lista')
    titulo = 'Modificar presupuesto'
    volver = 'presupuesto_lista'

    def get_queryset(self):
        return Presupuesto.objects.filter(categoria__usuario=self.request.user)

    def form_valid(self, form):
        respuesta = super().form_valid(form)
        messages.success(self.request, 'Presupuesto modificado correctamente')
        _avisar_si_hay_alerta(self.request, evaluar_presupuesto(self.object))
        return respuesta


class PresupuestoDeleteView(EliminarMixin, DeleteView):
    success_url = reverse_lazy('presupuesto_lista')
    volver = 'presupuesto_lista'
    mensaje_ok = 'Presupuesto eliminado correctamente'

    def get_queryset(self):
        return Presupuesto.objects.filter(categoria__usuario=self.request.user)


# --- Alertas ----------------------------------------------------------------

class AlertaListView(LoginRequiredMixin, ListView):
    template_name = 'finanzas/alerta_list.html'
    context_object_name = 'alertas'
    paginate_by = 10

    def get_queryset(self):
        return Alerta.objects.filter(
            presupuesto__categoria__usuario=self.request.user
        ).select_related('presupuesto__categoria')


@login_required
@require_POST
def alerta_marcar_leida(request, pk):
    alerta = get_object_or_404(
        Alerta, pk=pk, presupuesto__categoria__usuario=request.user
    )
    alerta.leida = True
    alerta.save(update_fields=['leida'])
    return redirect('alerta_lista')
