"""Logica de negocio: calculo de presupuestos, alertas y resumen mensual.

Se mantiene separada de las vistas para poder probarla de forma aislada.
"""
from datetime import date, timedelta
from decimal import Decimal

from django.db.models import Sum

from .models import Alerta, Categoria, Movimiento, Presupuesto

UMBRAL_ADVERTENCIA = Decimal('80')
UMBRAL_EXCEDIDO = Decimal('100')
ESTADO_OK = 'ok'

CATEGORIAS_INICIALES = [
    'Alimentacion', 'Transporte', 'Vivienda', 'Salud', 'Entretenimiento', 'Sueldo',
]


def primer_dia_mes(fecha):
    return fecha.replace(day=1)


def siguiente_mes(inicio):
    if inicio.month == 12:
        return date(inicio.year + 1, 1, 1)
    return date(inicio.year, inicio.month + 1, 1)


def crear_categorias_iniciales(usuario):
    for nombre in CATEGORIAS_INICIALES:
        Categoria.objects.get_or_create(usuario=usuario, nombre=nombre)


def total_gastado(categoria, mes):
    """Suma de los gastos (no ingresos) de una categoria dentro del mes indicado."""
    inicio = primer_dia_mes(mes)
    total = Movimiento.objects.filter(
        categoria=categoria,
        tipo=Movimiento.GASTO,
        fecha__gte=inicio,
        fecha__lt=siguiente_mes(inicio),
    ).aggregate(total=Sum('monto'))['total']
    return total or Decimal('0')


def clasificar(porcentaje):
    if porcentaje >= UMBRAL_EXCEDIDO:
        return Alerta.EXCEDIDO
    if porcentaje >= UMBRAL_ADVERTENCIA:
        return Alerta.ADVERTENCIA
    return ESTADO_OK


def estado_presupuesto(presupuesto):
    gastado = total_gastado(presupuesto.categoria, presupuesto.mes)
    porcentaje = gastado * 100 / presupuesto.monto_maximo
    return {
        'presupuesto': presupuesto,
        'gastado': gastado,
        'restante': presupuesto.monto_maximo - gastado,
        'porcentaje': int(porcentaje),
        'barra': min(int(porcentaje), 100),
        'estado': clasificar(porcentaje),
    }


def evaluar_presupuesto(presupuesto):
    """Genera una alerta si corresponde. No repite alertas del mismo tipo."""
    info = estado_presupuesto(presupuesto)
    if info['estado'] == ESTADO_OK:
        return None
    if presupuesto.alertas.filter(tipo=info['estado']).exists():
        return None
    return Alerta.objects.create(
        presupuesto=presupuesto, tipo=info['estado'], porcentaje=info['porcentaje']
    )


def evaluar_movimiento(movimiento):
    """Se invoca tras guardar un movimiento: solo los gastos pueden originar alertas."""
    if movimiento.tipo != Movimiento.GASTO:
        return None
    presupuesto = Presupuesto.objects.filter(
        categoria=movimiento.categoria, mes=primer_dia_mes(movimiento.fecha)
    ).first()
    if presupuesto is None:
        return None
    return evaluar_presupuesto(presupuesto)


def resumen_mensual(usuario, mes):
    inicio = primer_dia_mes(mes)
    movimientos = Movimiento.objects.filter(
        usuario=usuario, fecha__gte=inicio, fecha__lt=siguiente_mes(inicio)
    )
    ingresos = movimientos.filter(tipo=Movimiento.INGRESO).aggregate(t=Sum('monto'))['t'] or Decimal('0')
    gastos = movimientos.filter(tipo=Movimiento.GASTO).aggregate(t=Sum('monto'))['t'] or Decimal('0')
    presupuestos = Presupuesto.objects.filter(
        categoria__usuario=usuario, mes=inicio
    ).select_related('categoria')
    return {
        'mes': inicio,
        'ingresos': ingresos,
        'gastos': gastos,
        'saldo': ingresos - gastos,
        'estados': [estado_presupuesto(p) for p in presupuestos],
        'por_categoria': list(
            movimientos.filter(tipo=Movimiento.GASTO)
            .values('categoria__nombre')
            .annotate(total=Sum('monto'))
            .order_by('-total')
        ),
    }


def filtrar_movimientos(usuario, filtro):
    """Aplica los filtros validados del formulario sobre los movimientos del usuario."""
    consulta = Movimiento.objects.filter(usuario=usuario).select_related('categoria')
    if filtro.is_valid():
        datos = filtro.cleaned_data
        if datos.get('desde'):
            consulta = consulta.filter(fecha__gte=datos['desde'])
        if datos.get('hasta'):
            consulta = consulta.filter(fecha__lte=datos['hasta'])
        if datos.get('categoria'):
            consulta = consulta.filter(categoria=datos['categoria'])
        if datos.get('tipo'):
            consulta = consulta.filter(tipo=datos['tipo'])
        if datos.get('q'):
            consulta = consulta.filter(descripcion__icontains=datos['q'])
    return consulta
