from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import NON_FIELD_ERRORS
from django.utils import timezone

from .models import Categoria, Movimiento, Presupuesto

User = get_user_model()

ANIO_MINIMO = 2000
ANIO_MAXIMO = 2100


class RegistroForm(UserCreationForm):
    email = forms.EmailField(label='Correo electronico', required=True)

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ('username', 'email')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for campo in self.fields.values():
            campo.widget.attrs['class'] = 'form-control'

    def clean_email(self):
        email = self.cleaned_data['email'].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError('Ya existe una cuenta con ese correo')
        return email


class FormularioUsuario(forms.ModelForm):
    """Base para formularios que dependen del usuario conectado."""

    def __init__(self, *args, user, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = user

    def _categorias_del_usuario(self, campo):
        self.fields[campo].queryset = Categoria.objects.filter(usuario=self.user)
        self.fields[campo].empty_label = 'Seleccione una categoria'


class CategoriaForm(FormularioUsuario):
    class Meta:
        model = Categoria
        fields = ['nombre']
        widgets = {'nombre': forms.TextInput(attrs={'class': 'form-control'})}

    def clean_nombre(self):
        nombre = self.cleaned_data['nombre'].strip()
        if len(nombre) < 2:
            raise forms.ValidationError('El nombre debe tener al menos 2 caracteres')
        repetidas = Categoria.objects.filter(usuario=self.user, nombre__iexact=nombre)
        if self.instance.pk:
            repetidas = repetidas.exclude(pk=self.instance.pk)
        if repetidas.exists():
            raise forms.ValidationError('Ya tiene una categoria con ese nombre')
        return nombre


class MovimientoForm(FormularioUsuario):
    class Meta:
        model = Movimiento
        fields = ['tipo', 'categoria', 'monto', 'fecha', 'descripcion']
        widgets = {
            'tipo': forms.Select(attrs={'class': 'form-select'}),
            'categoria': forms.Select(attrs={'class': 'form-select'}),
            'monto': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'step': 1}),
            'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}, format='%Y-%m-%d'),
            'descripcion': forms.TextInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._categorias_del_usuario('categoria')
        self.fields['fecha'].input_formats = ['%Y-%m-%d']

    def clean_fecha(self):
        fecha = self.cleaned_data['fecha']
        if fecha > timezone.localdate():
            raise forms.ValidationError('La fecha no puede ser futura')
        if fecha.year < ANIO_MINIMO:
            raise forms.ValidationError(f'La fecha no puede ser anterior al año {ANIO_MINIMO}')
        return fecha

    def clean_descripcion(self):
        return self.cleaned_data['descripcion'].strip()


class PresupuestoForm(FormularioUsuario):
    mes = forms.DateField(
        label='Mes',
        input_formats=['%Y-%m'],
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'month'}, format='%Y-%m'),
    )

    class Meta:
        model = Presupuesto
        fields = ['categoria', 'mes', 'monto_maximo']
        labels = {'monto_maximo': 'Monto maximo'}
        error_messages = {
            NON_FIELD_ERRORS: {
                'unique_together': 'Ya existe un presupuesto para esa categoria en ese mes.',
            }
        }
        widgets = {
            'categoria': forms.Select(attrs={'class': 'form-select'}),
            'monto_maximo': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'step': 1}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._categorias_del_usuario('categoria')

    def clean_mes(self):
        mes = self.cleaned_data['mes']
        if not ANIO_MINIMO <= mes.year <= ANIO_MAXIMO:
            raise forms.ValidationError(f'El año debe estar entre {ANIO_MINIMO} y {ANIO_MAXIMO}')
        return mes.replace(day=1)


class FiltroMovimientosForm(forms.Form):
    desde = forms.DateField(
        required=False, input_formats=['%Y-%m-%d'],
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}, format='%Y-%m-%d'),
    )
    hasta = forms.DateField(
        required=False, input_formats=['%Y-%m-%d'],
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}, format='%Y-%m-%d'),
    )
    categoria = forms.ModelChoiceField(
        queryset=Categoria.objects.none(), required=False, empty_label='Todas',
        widget=forms.Select(attrs={'class': 'form-select'}),
    )
    tipo = forms.ChoiceField(
        required=False, choices=[('', 'Todos')] + Movimiento.TIPOS,
        widget=forms.Select(attrs={'class': 'form-select'}),
    )
    q = forms.CharField(
        required=False, max_length=100, label='Texto',
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Buscar en descripcion'}),
    )

    def __init__(self, *args, user, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['categoria'].queryset = Categoria.objects.filter(usuario=user)

    def clean(self):
        datos = super().clean()
        if datos.get('desde') and datos.get('hasta') and datos['desde'] > datos['hasta']:
            raise forms.ValidationError('La fecha "desde" no puede ser posterior a "hasta"')
        return datos
