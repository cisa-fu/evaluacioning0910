from django.contrib import admin

from .models import Alerta, Categoria, Movimiento, Presupuesto

admin.site.register(Categoria)
admin.site.register(Movimiento)
admin.site.register(Presupuesto)
admin.site.register(Alerta)
