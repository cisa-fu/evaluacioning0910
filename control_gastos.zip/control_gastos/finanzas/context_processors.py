from .models import Alerta


def alertas_pendientes(request):
    if not request.user.is_authenticated:
        return {}
    cantidad = Alerta.objects.filter(
        presupuesto__categoria__usuario=request.user, leida=False
    ).count()
    return {'alertas_pendientes': cantidad}
