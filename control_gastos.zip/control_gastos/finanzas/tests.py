"""Pruebas automatizadas del sistema de control de gastos.

Cada clase agrupa los casos de un requerimiento. Ejecutar con:
    python manage.py test -v 2
"""
from datetime import timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import Alerta, Categoria, Movimiento, Presupuesto
from .services import crear_categorias_iniciales, estado_presupuesto, resumen_mensual

User = get_user_model()
CLAVE = 'ClaveSegura#2026'


def hoy():
    return timezone.localdate()


def mes_actual():
    return hoy().replace(day=1)


def mes_anterior():
    return (mes_actual() - timedelta(days=1)).replace(day=1)


class BaseTest(TestCase):
    """Crea dos usuarios con una categoria cada uno para probar aislamiento."""

    @classmethod
    def setUpTestData(cls):
        cls.ana = User.objects.create_user('ana', 'ana@test.cl', CLAVE)
        cls.beto = User.objects.create_user('beto', 'beto@test.cl', CLAVE)
        cls.cat_ana = Categoria.objects.create(usuario=cls.ana, nombre='Comida')
        cls.cat_beto = Categoria.objects.create(usuario=cls.beto, nombre='Comida')

    def entrar(self, usuario='ana'):
        self.client.login(username=usuario, password=CLAVE)

    def gasto(self, monto, categoria=None, usuario=None, fecha=None, tipo=Movimiento.GASTO):
        return Movimiento.objects.create(
            usuario=usuario or self.ana, categoria=categoria or self.cat_ana,
            tipo=tipo, monto=monto, fecha=fecha or hoy(),
        )

    def datos_movimiento(self, **cambios):
        datos = {
            'tipo': 'gasto', 'categoria': self.cat_ana.pk, 'monto': '5000',
            'fecha': hoy().isoformat(), 'descripcion': 'Almuerzo',
        }
        datos.update(cambios)
        return datos


# --- RF-01 / RF-02: registro, inicio y cierre de sesion ----------------------

class AutenticacionTests(BaseTest):

    def test_registro_valido_crea_usuario_y_categorias_iniciales(self):
        r = self.client.post(reverse('registro'), {
            'username': 'carla', 'email': 'carla@test.cl',
            'password1': CLAVE, 'password2': CLAVE,
        })
        self.assertRedirects(r, reverse('login'))
        usuario = User.objects.get(username='carla')
        self.assertTrue(usuario.categorias.filter(nombre='Alimentacion').exists())

    def test_registro_rechaza_contrasena_corta(self):
        r = self.client.post(reverse('registro'), {
            'username': 'carla', 'email': 'c@test.cl', 'password1': 'Ab1#', 'password2': 'Ab1#',
        })
        self.assertEqual(r.status_code, 200)
        self.assertFalse(User.objects.filter(username='carla').exists())

    def test_registro_rechaza_contrasena_comun(self):
        r = self.client.post(reverse('registro'), {
            'username': 'carla', 'email': 'c@test.cl',
            'password1': 'password123', 'password2': 'password123',
        })
        self.assertFalse(User.objects.filter(username='carla').exists())

    def test_registro_rechaza_contrasenas_distintas(self):
        self.client.post(reverse('registro'), {
            'username': 'carla', 'email': 'c@test.cl',
            'password1': CLAVE, 'password2': CLAVE + 'x',
        })
        self.assertFalse(User.objects.filter(username='carla').exists())

    def test_registro_rechaza_correo_duplicado_sin_distinguir_mayusculas(self):
        r = self.client.post(reverse('registro'), {
            'username': 'carla', 'email': 'ANA@test.cl', 'password1': CLAVE, 'password2': CLAVE,
        })
        self.assertContains(r, 'Ya existe una cuenta con ese correo')

    def test_registro_rechaza_usuario_duplicado(self):
        self.client.post(reverse('registro'), {
            'username': 'ana', 'email': 'otra@test.cl', 'password1': CLAVE, 'password2': CLAVE,
        })
        self.assertEqual(User.objects.filter(username='ana').count(), 1)

    def test_contrasena_se_guarda_con_hash(self):
        self.assertNotEqual(self.ana.password, CLAVE)
        self.assertTrue(self.ana.password.startswith(('pbkdf2_', 'argon2', 'bcrypt')))

    def test_login_correcto(self):
        r = self.client.post(reverse('login'), {'username': 'ana', 'password': CLAVE})
        self.assertRedirects(r, reverse('principal'))

    def test_login_con_clave_incorrecta(self):
        r = self.client.post(reverse('login'), {'username': 'ana', 'password': 'mala'})
        self.assertContains(r, 'Usuario o contrasena incorrectos')

    def test_login_no_acepta_redireccion_externa(self):
        r = self.client.post(
            reverse('login') + '?next=https://sitio-malicioso.com',
            {'username': 'ana', 'password': CLAVE},
        )
        self.assertNotIn('sitio-malicioso', r['Location'])

    def test_logout_requiere_post(self):
        self.entrar()
        self.assertEqual(self.client.get(reverse('logout')).status_code, 405)
        r = self.client.post(reverse('logout'))
        self.assertRedirects(r, reverse('login'), fetch_redirect_response=False)

    def test_rutas_protegidas_redirigen_al_login(self):
        rutas = [
            'principal', 'categoria_lista', 'categoria_crear', 'movimiento_lista',
            'movimiento_crear', 'movimiento_exportar', 'presupuesto_lista',
            'presupuesto_crear', 'alerta_lista',
        ]
        for nombre in rutas:
            with self.subTest(ruta=nombre):
                r = self.client.get(reverse(nombre))
                self.assertEqual(r.status_code, 302)
                self.assertIn('/accounts/login/', r['Location'])

    def test_rutas_con_id_protegidas_sin_sesion(self):
        mov = self.gasto(1000)
        for nombre in ['movimiento_editar', 'movimiento_eliminar', 'categoria_editar', 'categoria_eliminar']:
            pk = mov.pk if nombre.startswith('movimiento') else self.cat_ana.pk
            with self.subTest(ruta=nombre):
                r = self.client.get(reverse(nombre, args=[pk]))
                self.assertEqual(r.status_code, 302)

    def test_cookie_de_sesion_es_httponly(self):
        r = self.client.post(reverse('login'), {'username': 'ana', 'password': CLAVE})
        self.assertTrue(r.cookies['sessionid']['httponly'])


# --- RF-03: categorias -------------------------------------------------------

class CategoriaTests(BaseTest):

    def setUp(self):
        self.entrar()

    def test_crear_categoria(self):
        self.client.post(reverse('categoria_crear'), {'nombre': 'Transporte'})
        self.assertTrue(Categoria.objects.filter(usuario=self.ana, nombre='Transporte').exists())

    def test_nombre_demasiado_corto(self):
        r = self.client.post(reverse('categoria_crear'), {'nombre': 'A'})
        self.assertContains(r, 'al menos 2 caracteres')

    def test_nombre_vacio(self):
        r = self.client.post(reverse('categoria_crear'), {'nombre': '   '})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(Categoria.objects.filter(usuario=self.ana).count(), 1)

    def test_nombre_duplicado_sin_distinguir_mayusculas(self):
        r = self.client.post(reverse('categoria_crear'), {'nombre': 'comida'})
        self.assertContains(r, 'Ya tiene una categoria con ese nombre')

    def test_otro_usuario_puede_usar_el_mismo_nombre(self):
        self.client.logout()
        self.entrar('beto')
        r = self.client.post(reverse('categoria_crear'), {'nombre': 'Transporte'})
        self.assertEqual(r.status_code, 302)

    def test_modificar_categoria_conserva_su_propio_nombre(self):
        r = self.client.post(reverse('categoria_editar', args=[self.cat_ana.pk]), {'nombre': 'Comida'})
        self.assertEqual(r.status_code, 302)

    def test_eliminar_categoria_sin_movimientos(self):
        self.client.post(reverse('categoria_eliminar', args=[self.cat_ana.pk]))
        self.assertFalse(Categoria.objects.filter(pk=self.cat_ana.pk).exists())

    def test_no_elimina_categoria_con_movimientos(self):
        self.gasto(1000)
        r = self.client.post(reverse('categoria_eliminar', args=[self.cat_ana.pk]), follow=True)
        self.assertTrue(Categoria.objects.filter(pk=self.cat_ana.pk).exists())
        self.assertContains(r, 'No se puede eliminar una categoria')

    def test_no_puede_modificar_ni_eliminar_categoria_ajena(self):
        self.assertEqual(self.client.get(reverse('categoria_editar', args=[self.cat_beto.pk])).status_code, 404)
        self.assertEqual(self.client.post(reverse('categoria_eliminar', args=[self.cat_beto.pk])).status_code, 404)
        self.assertTrue(Categoria.objects.filter(pk=self.cat_beto.pk).exists())

    def test_listado_solo_muestra_categorias_propias(self):
        Categoria.objects.create(usuario=self.beto, nombre='SoloDeBeto')
        r = self.client.get(reverse('categoria_lista'))
        self.assertNotContains(r, 'SoloDeBeto')


# --- RF-04 / RF-05: registrar, modificar y eliminar movimientos --------------

class MovimientoTests(BaseTest):

    def setUp(self):
        self.entrar()

    def test_registrar_gasto_valido(self):
        r = self.client.post(reverse('movimiento_crear'), self.datos_movimiento())
        self.assertRedirects(r, reverse('movimiento_lista'))
        m = Movimiento.objects.get()
        self.assertEqual(m.usuario, self.ana)
        self.assertEqual(m.monto, Decimal('5000'))

    def test_registrar_ingreso_valido(self):
        self.client.post(reverse('movimiento_crear'), self.datos_movimiento(tipo='ingreso', monto='900000'))
        self.assertEqual(Movimiento.objects.get().tipo, 'ingreso')

    def test_monto_cero_rechazado(self):
        self.client.post(reverse('movimiento_crear'), self.datos_movimiento(monto='0'))
        self.assertEqual(Movimiento.objects.count(), 0)

    def test_monto_negativo_rechazado(self):
        self.client.post(reverse('movimiento_crear'), self.datos_movimiento(monto='-500'))
        self.assertEqual(Movimiento.objects.count(), 0)

    def test_monto_no_numerico_rechazado(self):
        self.client.post(reverse('movimiento_crear'), self.datos_movimiento(monto='abc'))
        self.assertEqual(Movimiento.objects.count(), 0)

    def test_monto_con_decimales_rechazado(self):
        self.client.post(reverse('movimiento_crear'), self.datos_movimiento(monto='100.5'))
        self.assertEqual(Movimiento.objects.count(), 0)

    def test_monto_excesivo_rechazado(self):
        self.client.post(reverse('movimiento_crear'), self.datos_movimiento(monto='1000000000'))
        self.assertEqual(Movimiento.objects.count(), 0)

    def test_monto_vacio_rechazado(self):
        self.client.post(reverse('movimiento_crear'), self.datos_movimiento(monto=''))
        self.assertEqual(Movimiento.objects.count(), 0)

    def test_fecha_futura_rechazada(self):
        manana = (hoy() + timedelta(days=1)).isoformat()
        r = self.client.post(reverse('movimiento_crear'), self.datos_movimiento(fecha=manana))
        self.assertContains(r, 'La fecha no puede ser futura')

    def test_fecha_con_formato_invalido_rechazada(self):
        self.client.post(reverse('movimiento_crear'), self.datos_movimiento(fecha='31-02-2026'))
        self.assertEqual(Movimiento.objects.count(), 0)

    def test_fecha_demasiado_antigua_rechazada(self):
        self.client.post(reverse('movimiento_crear'), self.datos_movimiento(fecha='1900-01-01'))
        self.assertEqual(Movimiento.objects.count(), 0)

    def test_tipo_invalido_rechazado(self):
        self.client.post(reverse('movimiento_crear'), self.datos_movimiento(tipo='regalo'))
        self.assertEqual(Movimiento.objects.count(), 0)

    def test_no_permite_usar_categoria_de_otro_usuario(self):
        self.client.post(reverse('movimiento_crear'), self.datos_movimiento(categoria=self.cat_beto.pk))
        self.assertEqual(Movimiento.objects.count(), 0)

    def test_no_se_puede_asignar_el_movimiento_a_otro_usuario(self):
        datos = self.datos_movimiento()
        datos['usuario'] = self.beto.pk
        self.client.post(reverse('movimiento_crear'), datos)
        self.assertEqual(Movimiento.objects.get().usuario, self.ana)

    def test_descripcion_con_html_se_escapa(self):
        self.gasto(1000)
        Movimiento.objects.update(descripcion='<script>alert(1)</script>')
        r = self.client.get(reverse('movimiento_lista'))
        self.assertNotContains(r, '<script>alert(1)</script>')
        self.assertContains(r, '&lt;script&gt;')

    def test_modificar_movimiento_propio(self):
        m = self.gasto(1000)
        self.client.post(reverse('movimiento_editar', args=[m.pk]), self.datos_movimiento(monto='2500'))
        m.refresh_from_db()
        self.assertEqual(m.monto, Decimal('2500'))

    def test_eliminar_movimiento_propio(self):
        m = self.gasto(1000)
        self.client.post(reverse('movimiento_eliminar', args=[m.pk]))
        self.assertFalse(Movimiento.objects.filter(pk=m.pk).exists())

    def test_no_puede_ver_modificar_ni_eliminar_movimiento_ajeno(self):
        ajeno = self.gasto(1000, categoria=self.cat_beto, usuario=self.beto)
        self.assertEqual(self.client.get(reverse('movimiento_editar', args=[ajeno.pk])).status_code, 404)
        self.assertEqual(
            self.client.post(reverse('movimiento_editar', args=[ajeno.pk]), self.datos_movimiento()).status_code, 404)
        self.assertEqual(self.client.post(reverse('movimiento_eliminar', args=[ajeno.pk])).status_code, 404)
        self.assertTrue(Movimiento.objects.filter(pk=ajeno.pk).exists())

    def test_eliminar_requiere_post_para_borrar(self):
        m = self.gasto(1000)
        self.client.get(reverse('movimiento_eliminar', args=[m.pk]))
        self.assertTrue(Movimiento.objects.filter(pk=m.pk).exists())

    def test_post_sin_token_csrf_es_rechazado(self):
        from django.test import Client
        cliente = Client(enforce_csrf_checks=True)
        cliente.login(username='ana', password=CLAVE)
        r = cliente.post(reverse('movimiento_crear'), self.datos_movimiento())
        self.assertEqual(r.status_code, 403)
        self.assertEqual(Movimiento.objects.count(), 0)


# --- RF-06: consulta con filtros --------------------------------------------

class ListadoTests(BaseTest):

    def setUp(self):
        self.entrar()
        self.otra = Categoria.objects.create(usuario=self.ana, nombre='Ocio')
        self.m1 = self.gasto(1000, fecha=hoy() - timedelta(days=40))
        self.m2 = self.gasto(2000, categoria=self.otra)
        self.m3 = self.gasto(9000, tipo=Movimiento.INGRESO)
        Movimiento.objects.filter(pk=self.m2.pk).update(descripcion='Cine con amigos')
        self.ajeno = self.gasto(777, categoria=self.cat_beto, usuario=self.beto)

    def ids(self, **parametros):
        r = self.client.get(reverse('movimiento_lista'), parametros)
        return {m.pk for m in r.context['movimientos']}

    def test_sin_filtros_muestra_solo_los_propios(self):
        self.assertEqual(self.ids(), {self.m1.pk, self.m2.pk, self.m3.pk})

    def test_filtro_por_categoria(self):
        self.assertEqual(self.ids(categoria=self.otra.pk), {self.m2.pk})

    def test_filtro_por_tipo(self):
        self.assertEqual(self.ids(tipo='ingreso'), {self.m3.pk})

    def test_filtro_por_rango_de_fechas(self):
        self.assertEqual(self.ids(desde=(hoy() - timedelta(days=5)).isoformat()), {self.m2.pk, self.m3.pk})
        self.assertEqual(self.ids(hasta=(hoy() - timedelta(days=5)).isoformat()), {self.m1.pk})

    def test_filtro_por_texto(self):
        self.assertEqual(self.ids(q='cine'), {self.m2.pk})

    def test_filtro_con_categoria_ajena_no_filtra_ni_filtra_datos_de_otros(self):
        ids = self.ids(categoria=self.cat_beto.pk)
        self.assertNotIn(self.ajeno.pk, ids)

    def test_rango_de_fechas_invertido_muestra_error(self):
        r = self.client.get(reverse('movimiento_lista'), {
            'desde': hoy().isoformat(), 'hasta': (hoy() - timedelta(days=3)).isoformat()})
        self.assertContains(r, 'no puede ser posterior')

    def test_inyeccion_sql_en_busqueda_no_rompe_ni_devuelve_datos(self):
        r = self.client.get(reverse('movimiento_lista'), {'q': "' OR '1'='1' --"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(len(r.context['movimientos']), 0)

    def test_parametros_absurdos_no_producen_error_500(self):
        for parametros in [{'desde': 'xx'}, {'categoria': 'abc'}, {'tipo': '<b>'}, {'page': '9999'}]:
            with self.subTest(parametros=parametros):
                r = self.client.get(reverse('movimiento_lista'), parametros)
                self.assertIn(r.status_code, (200, 404))

    def test_paginacion(self):
        for _ in range(12):
            self.gasto(100)
        r = self.client.get(reverse('movimiento_lista'))
        self.assertTrue(r.context['is_paginated'])
        self.assertEqual(len(r.context['movimientos']), 10)


# --- RF-07: presupuestos -----------------------------------------------------

class PresupuestoTests(BaseTest):

    def setUp(self):
        self.entrar()

    def datos(self, **cambios):
        d = {'categoria': self.cat_ana.pk, 'mes': mes_actual().strftime('%Y-%m'), 'monto_maximo': '100000'}
        d.update(cambios)
        return d

    def test_crear_presupuesto(self):
        r = self.client.post(reverse('presupuesto_crear'), self.datos())
        self.assertRedirects(r, reverse('presupuesto_lista'))
        p = Presupuesto.objects.get()
        self.assertEqual(p.mes, mes_actual())

    def test_monto_cero_o_negativo_rechazado(self):
        for monto in ['0', '-1000']:
            with self.subTest(monto=monto):
                self.client.post(reverse('presupuesto_crear'), self.datos(monto_maximo=monto))
                self.assertEqual(Presupuesto.objects.count(), 0)

    def test_presupuesto_duplicado_para_misma_categoria_y_mes_rechazado(self):
        self.client.post(reverse('presupuesto_crear'), self.datos())
        r = self.client.post(reverse('presupuesto_crear'), self.datos(monto_maximo='5000'))
        self.assertContains(r, 'Ya existe un presupuesto')
        self.assertEqual(Presupuesto.objects.count(), 1)

    def test_mismo_mes_en_otra_categoria_es_valido(self):
        otra = Categoria.objects.create(usuario=self.ana, nombre='Ocio')
        self.client.post(reverse('presupuesto_crear'), self.datos())
        self.client.post(reverse('presupuesto_crear'), self.datos(categoria=otra.pk))
        self.assertEqual(Presupuesto.objects.count(), 2)

    def test_mes_con_formato_invalido_rechazado(self):
        for mes in ['abril', '2026-13', '13/2026', '']:
            with self.subTest(mes=mes):
                self.client.post(reverse('presupuesto_crear'), self.datos(mes=mes))
                self.assertEqual(Presupuesto.objects.count(), 0)

    def test_anio_fuera_de_rango_rechazado(self):
        self.client.post(reverse('presupuesto_crear'), self.datos(mes='9999-12'))
        self.assertEqual(Presupuesto.objects.count(), 0)

    def test_no_permite_presupuesto_sobre_categoria_ajena(self):
        self.client.post(reverse('presupuesto_crear'), self.datos(categoria=self.cat_beto.pk))
        self.assertEqual(Presupuesto.objects.count(), 0)

    def test_modificar_presupuesto_propio(self):
        p = Presupuesto.objects.create(categoria=self.cat_ana, mes=mes_actual(), monto_maximo=100000)
        self.client.post(reverse('presupuesto_editar', args=[p.pk]), self.datos(monto_maximo='250000'))
        p.refresh_from_db()
        self.assertEqual(p.monto_maximo, Decimal('250000'))

    def test_eliminar_presupuesto_propio(self):
        p = Presupuesto.objects.create(categoria=self.cat_ana, mes=mes_actual(), monto_maximo=100000)
        self.client.post(reverse('presupuesto_eliminar', args=[p.pk]))
        self.assertEqual(Presupuesto.objects.count(), 0)

    def test_no_puede_modificar_ni_eliminar_presupuesto_ajeno(self):
        p = Presupuesto.objects.create(categoria=self.cat_beto, mes=mes_actual(), monto_maximo=100000)
        self.assertEqual(self.client.get(reverse('presupuesto_editar', args=[p.pk])).status_code, 404)
        self.assertEqual(self.client.post(reverse('presupuesto_eliminar', args=[p.pk])).status_code, 404)
        self.assertEqual(Presupuesto.objects.count(), 1)


# --- RF-08 / RF-09: generacion y consulta de alertas -------------------------

class AlertaTests(BaseTest):

    def setUp(self):
        self.entrar()
        self.presupuesto = Presupuesto.objects.create(
            categoria=self.cat_ana, mes=mes_actual(), monto_maximo=100000)

    def registrar(self, monto, **cambios):
        return self.client.post(reverse('movimiento_crear'), self.datos_movimiento(monto=str(monto), **cambios))

    def test_bajo_el_80_por_ciento_no_genera_alerta(self):
        self.registrar(79999)
        self.assertEqual(Alerta.objects.count(), 0)

    def test_exactamente_80_por_ciento_genera_advertencia(self):
        self.registrar(80000)
        a = Alerta.objects.get()
        self.assertEqual(a.tipo, Alerta.ADVERTENCIA)
        self.assertEqual(a.porcentaje, 80)

    def test_exactamente_100_por_ciento_genera_alerta_de_excedido(self):
        self.registrar(100000)
        self.assertEqual(Alerta.objects.get().tipo, Alerta.EXCEDIDO)

    def test_sobre_el_100_por_ciento_genera_alerta_de_excedido(self):
        self.registrar(150000)
        a = Alerta.objects.get()
        self.assertEqual(a.tipo, Alerta.EXCEDIDO)
        self.assertEqual(a.porcentaje, 150)

    def test_acumula_gastos_y_cruza_el_umbral(self):
        self.registrar(50000)
        self.assertEqual(Alerta.objects.count(), 0)
        self.registrar(35000)
        self.assertEqual(Alerta.objects.get().tipo, Alerta.ADVERTENCIA)

    def test_no_repite_la_misma_alerta(self):
        self.registrar(85000)
        self.registrar(1000)
        self.assertEqual(Alerta.objects.filter(tipo=Alerta.ADVERTENCIA).count(), 1)

    def test_pasa_de_advertencia_a_excedido_con_alertas_distintas(self):
        self.registrar(85000)
        self.registrar(20000)
        self.assertEqual(set(Alerta.objects.values_list('tipo', flat=True)),
                         {Alerta.ADVERTENCIA, Alerta.EXCEDIDO})

    def test_los_ingresos_no_cuentan_para_el_presupuesto(self):
        self.registrar(200000, tipo='ingreso')
        self.assertEqual(Alerta.objects.count(), 0)

    def test_gastos_de_otro_mes_no_cuentan(self):
        self.gasto(200000, fecha=mes_anterior())
        self.registrar(1000)
        self.assertEqual(Alerta.objects.count(), 0)

    def test_gastos_de_otra_categoria_no_cuentan(self):
        otra = Categoria.objects.create(usuario=self.ana, nombre='Ocio')
        self.registrar(200000, categoria=otra.pk)
        self.assertEqual(Alerta.objects.count(), 0)

    def test_sin_presupuesto_no_hay_alerta(self):
        self.presupuesto.delete()
        self.registrar(500000)
        self.assertEqual(Alerta.objects.count(), 0)

    def test_gastos_de_otro_usuario_no_afectan_mi_presupuesto(self):
        self.gasto(500000, categoria=self.cat_beto, usuario=self.beto)
        self.registrar(1000)
        self.assertEqual(Alerta.objects.count(), 0)

    def test_crear_presupuesto_cuando_ya_se_gasto_de_mas_genera_alerta(self):
        self.presupuesto.delete()
        self.gasto(120000)
        self.client.post(reverse('presupuesto_crear'), {
            'categoria': self.cat_ana.pk, 'mes': mes_actual().strftime('%Y-%m'), 'monto_maximo': '100000'})
        self.assertEqual(Alerta.objects.get().tipo, Alerta.EXCEDIDO)

    def test_reducir_el_presupuesto_puede_generar_alerta(self):
        self.gasto(60000)
        self.client.post(reverse('presupuesto_editar', args=[self.presupuesto.pk]), {
            'categoria': self.cat_ana.pk, 'mes': mes_actual().strftime('%Y-%m'), 'monto_maximo': '70000'})
        self.assertEqual(Alerta.objects.get().tipo, Alerta.ADVERTENCIA)

    def test_modificar_un_gasto_puede_generar_alerta(self):
        m = self.gasto(10000)
        self.client.post(reverse('movimiento_editar', args=[m.pk]), self.datos_movimiento(monto='90000'))
        self.assertEqual(Alerta.objects.get().tipo, Alerta.ADVERTENCIA)

    def test_listado_solo_muestra_alertas_propias(self):
        pb = Presupuesto.objects.create(categoria=self.cat_beto, mes=mes_actual(), monto_maximo=10)
        Alerta.objects.create(presupuesto=pb, tipo=Alerta.EXCEDIDO, porcentaje=500)
        Alerta.objects.create(presupuesto=self.presupuesto, tipo=Alerta.ADVERTENCIA, porcentaje=80)
        r = self.client.get(reverse('alerta_lista'))
        self.assertEqual(len(r.context['alertas']), 1)

    def test_marcar_alerta_como_leida(self):
        a = Alerta.objects.create(presupuesto=self.presupuesto, tipo=Alerta.ADVERTENCIA, porcentaje=80)
        self.client.post(reverse('alerta_leida', args=[a.pk]))
        a.refresh_from_db()
        self.assertTrue(a.leida)

    def test_marcar_leida_exige_post(self):
        a = Alerta.objects.create(presupuesto=self.presupuesto, tipo=Alerta.ADVERTENCIA, porcentaje=80)
        self.assertEqual(self.client.get(reverse('alerta_leida', args=[a.pk])).status_code, 405)
        a.refresh_from_db()
        self.assertFalse(a.leida)

    def test_no_puede_marcar_alerta_ajena(self):
        pb = Presupuesto.objects.create(categoria=self.cat_beto, mes=mes_actual(), monto_maximo=10)
        ajena = Alerta.objects.create(presupuesto=pb, tipo=Alerta.EXCEDIDO, porcentaje=500)
        self.assertEqual(self.client.post(reverse('alerta_leida', args=[ajena.pk])).status_code, 404)
        ajena.refresh_from_db()
        self.assertFalse(ajena.leida)

    def test_contador_de_alertas_pendientes_en_la_pagina(self):
        Alerta.objects.create(presupuesto=self.presupuesto, tipo=Alerta.ADVERTENCIA, porcentaje=80)
        r = self.client.get(reverse('principal'))
        self.assertEqual(r.context['alertas_pendientes'], 1)


# --- RF-10: resumen mensual --------------------------------------------------

class ResumenTests(BaseTest):

    def test_totales_del_mes(self):
        self.gasto(300000, tipo=Movimiento.INGRESO)
        self.gasto(40000)
        self.gasto(10000)
        self.gasto(99999, fecha=mes_anterior())
        r = resumen_mensual(self.ana, mes_actual())
        self.assertEqual(r['ingresos'], 300000)
        self.assertEqual(r['gastos'], 50000)
        self.assertEqual(r['saldo'], 250000)

    def test_resumen_vacio(self):
        r = resumen_mensual(self.ana, mes_actual())
        self.assertEqual((r['ingresos'], r['gastos'], r['saldo']), (0, 0, 0))

    def test_resumen_no_incluye_datos_de_otros_usuarios(self):
        self.gasto(5000, categoria=self.cat_beto, usuario=self.beto)
        self.assertEqual(resumen_mensual(self.ana, mes_actual())['gastos'], 0)

    def test_estado_del_presupuesto_en_cada_tramo(self):
        p = Presupuesto.objects.create(categoria=self.cat_ana, mes=mes_actual(), monto_maximo=1000)
        self.assertEqual(estado_presupuesto(p)['estado'], 'ok')
        m = self.gasto(800)
        self.assertEqual(estado_presupuesto(p)['estado'], 'advertencia')
        m.monto = 1000
        m.save()
        self.assertEqual(estado_presupuesto(p)['estado'], 'excedido')

    def test_porcentaje_para_la_barra_no_supera_100(self):
        p = Presupuesto.objects.create(categoria=self.cat_ana, mes=mes_actual(), monto_maximo=1000)
        self.gasto(5000)
        info = estado_presupuesto(p)
        self.assertEqual(info['porcentaje'], 500)
        self.assertEqual(info['barra'], 100)

    def test_pagina_principal_se_muestra(self):
        self.entrar()
        self.assertEqual(self.client.get(reverse('principal')).status_code, 200)

    def test_mes_invalido_en_la_url_usa_el_mes_actual(self):
        self.entrar()
        for valor in ['abc', '2026-99', '9999-12', '0001-01', '<script>']:
            with self.subTest(valor=valor):
                r = self.client.get(reverse('principal'), {'mes': valor})
                self.assertEqual(r.status_code, 200)
                self.assertEqual(r.context['mes'], mes_actual())

    def test_mes_valido_en_la_url(self):
        self.entrar()
        r = self.client.get(reverse('principal'), {'mes': '2025-03'})
        self.assertEqual(r.context['mes'].isoformat(), '2025-03-01')

    def test_categorias_iniciales_no_se_duplican(self):
        crear_categorias_iniciales(self.ana)
        crear_categorias_iniciales(self.ana)
        self.assertEqual(self.ana.categorias.filter(nombre='Sueldo').count(), 1)


# --- RF-11: exportacion a CSV ------------------------------------------------

class ExportarTests(BaseTest):

    def setUp(self):
        self.entrar()

    def test_exporta_solo_movimientos_propios(self):
        self.gasto(1234)
        self.gasto(9876, categoria=self.cat_beto, usuario=self.beto)
        r = self.client.get(reverse('movimiento_exportar'))
        contenido = r.content.decode()
        self.assertIn('1234', contenido)
        self.assertNotIn('9876', contenido)
        self.assertEqual(r['Content-Type'], 'text/csv; charset=utf-8')

    def test_neutraliza_formulas_en_la_descripcion(self):
        self.gasto(1000)
        Movimiento.objects.update(descripcion='=HYPERLINK("http://malo.com")')
        contenido = self.client.get(reverse('movimiento_exportar')).content.decode()
        self.assertIn("'=HYPERLINK", contenido)
        self.assertNotIn(',=HYPERLINK', contenido)

    def test_exportacion_respeta_los_filtros(self):
        self.gasto(1111, tipo=Movimiento.INGRESO)
        self.gasto(2222)
        contenido = self.client.get(reverse('movimiento_exportar'), {'tipo': 'ingreso'}).content.decode()
        self.assertIn('1111', contenido)
        self.assertNotIn('2222', contenido)
