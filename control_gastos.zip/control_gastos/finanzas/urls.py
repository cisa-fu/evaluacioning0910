from django.contrib.auth import views as auth_views
from django.urls import path

from . import views

urlpatterns = [
    path('', views.principal, name='principal'),

    path('registro/', views.RegistroView.as_view(), name='registro'),
    path('accounts/login/', views.InicioSesionView.as_view(), name='login'),
    path('accounts/logout/', auth_views.LogoutView.as_view(), name='logout'),

    path('categorias/', views.CategoriaListView.as_view(), name='categoria_lista'),
    path('categorias/crear/', views.CategoriaCreateView.as_view(), name='categoria_crear'),
    path('categorias/<int:pk>/editar/', views.CategoriaUpdateView.as_view(), name='categoria_editar'),
    path('categorias/<int:pk>/eliminar/', views.CategoriaDeleteView.as_view(), name='categoria_eliminar'),

    path('movimientos/', views.MovimientoListView.as_view(), name='movimiento_lista'),
    path('movimientos/crear/', views.MovimientoCreateView.as_view(), name='movimiento_crear'),
    path('movimientos/exportar/', views.movimientos_exportar, name='movimiento_exportar'),
    path('movimientos/<int:pk>/editar/', views.MovimientoUpdateView.as_view(), name='movimiento_editar'),
    path('movimientos/<int:pk>/eliminar/', views.MovimientoDeleteView.as_view(), name='movimiento_eliminar'),

    path('presupuestos/', views.PresupuestoListView.as_view(), name='presupuesto_lista'),
    path('presupuestos/crear/', views.PresupuestoCreateView.as_view(), name='presupuesto_crear'),
    path('presupuestos/<int:pk>/editar/', views.PresupuestoUpdateView.as_view(), name='presupuesto_editar'),
    path('presupuestos/<int:pk>/eliminar/', views.PresupuestoDeleteView.as_view(), name='presupuesto_eliminar'),

    path('alertas/', views.AlertaListView.as_view(), name='alerta_lista'),
    path('alertas/<int:pk>/leida/', views.alerta_marcar_leida, name='alerta_leida'),
]
