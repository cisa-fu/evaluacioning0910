# Control de Gastos y Presupuestos (Django)

Aplicacion web para registrar ingresos y gastos, fijar un presupuesto mensual por
categoria y recibir alertas cuando el gasto alcanza el 80 % o supera el 100 % del limite.

Autora: C. Isabel Flores - Ingenieria de Software, INACAP.

## Puesta en marcha (desarrollo)

```bash
python3 -m venv venv
source venv/bin/activate            # Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser     # opcional, solo para /admin/
python manage.py runserver
```

Abrir http://127.0.0.1:8000/ , crear una cuenta en **Registrese** e iniciar sesion.
Al registrarse se crean categorias iniciales (Alimentacion, Transporte, Vivienda,
Salud, Entretenimiento, Sueldo). La base de datos es SQLite (`db.sqlite3`), no requiere instalar nada.

## Pruebas automatizadas

```bash
python manage.py test -v 2
```

96 pruebas agrupadas por requerimiento (autenticacion, categorias, movimientos,
listado y filtros, presupuestos, alertas, resumen, exportacion). Incluyen casos negativos:
montos invalidos, fechas futuras, acceso a datos de otro usuario, inyeccion SQL, XSS, CSRF y
inyeccion de formulas en CSV.

## Requerimientos funcionales y trazabilidad

| RF | Requerimiento | Vista / servicio | Entidad |
|---|---|---|---|
| RF-01 | Registrar usuario | `RegistroView` | User |
| RF-02 | Iniciar y cerrar sesion | `InicioSesionView`, `LogoutView` | User |
| RF-03 | Gestionar categorias | `Categoria*View` | Categoria |
| RF-04 | Registrar ingreso o gasto | `MovimientoCreateView` | Movimiento |
| RF-05 | Modificar y eliminar movimientos | `MovimientoUpdateView`, `MovimientoDeleteView` | Movimiento |
| RF-06 | Consultar movimientos con filtros | `MovimientoListView`, `filtrar_movimientos` | Movimiento |
| RF-07 | Configurar presupuesto mensual | `Presupuesto*View` | Presupuesto |
| RF-08 | Generar alertas (80 % / 100 %) | `services.evaluar_presupuesto` | Alerta |
| RF-09 | Consultar alertas | `AlertaListView`, `alerta_marcar_leida` | Alerta |
| RF-10 | Resumen mensual y estado por categoria | `principal`, `services.resumen_mensual` | Movimiento, Presupuesto |
| RF-11 | Exportar movimientos a CSV | `movimientos_exportar` | Movimiento |

## Arquitectura

Aplicacion web en capas (patron MTV de Django):

- Presentacion: plantillas en `finanzas/templates/` (Bootstrap 5).
- Controlador: `views.py`, `forms.py` (validacion de entradas) y `urls.py`.
- Logica de negocio: `services.py` (calculo de presupuestos y alertas), aislada y probada por separado.
- Datos: `models.py` + SQLite mediante el ORM de Django.

## Medidas de seguridad implementadas

| Riesgo (OWASP Top 10) | Medida |
|---|---|
| A01 Control de acceso | Todas las vistas exigen sesion; cada consulta se filtra por usuario (acceder a datos ajenos devuelve 404); los formularios solo ofrecen categorias propias. |
| A02 Fallas criptograficas | Contrasenas con hash PBKDF2; cookies seguras (`Secure`, HSTS y redireccion HTTPS) al desplegar con `DJANGO_DEBUG=0`. |
| A03 Inyeccion | Uso exclusivo del ORM (consultas parametrizadas); plantillas con escape automatico (XSS); neutralizacion de formulas en el CSV. |
| A04 Diseno inseguro | Validaciones de monto, fecha y rango de anios en servidor; restricciones unicas en BD; el borrado de categorias con movimientos esta protegido. |
| A05 Configuracion | Secretos por variables de entorno; `DEBUG` desactivable; `ALLOWED_HOSTS` restringido; cabeceras `X-Frame-Options`, `nosniff`, `Referrer-Policy`. |
| A07 Autenticacion | Clave minima de 10 caracteres con validadores de Django; sesion que expira a los 30 min; cierre de sesion solo por POST; CSRF en todos los formularios. |

### Limitaciones conocidas (candidatas a mejora)

- No hay limite de intentos fallidos de inicio de sesion (se podria agregar `django-axes`).
- No existe recuperacion de contrasena por correo.
- No hay registro de auditoria de cambios (quien modifico o elimino un movimiento).
- Las alertas se muestran en la aplicacion; no se envian por correo.

## Produccion

```bash
export DJANGO_DEBUG=0
export DJANGO_SECRET_KEY='<clave larga y aleatoria>'
export DJANGO_ALLOWED_HOSTS='mi-dominio.cl'
python manage.py check --deploy
```
